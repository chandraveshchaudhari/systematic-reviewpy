"""Module: analysis
It will contain code for generating diagrams and tables.
To-DO
"""